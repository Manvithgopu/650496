package com.example.hackfest;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hackfest.R.id;

public class MainActivity8 extends AppCompatActivity {
    TextView txt8hello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
//        txt8hello=findViewById(id.txt8hello);
//        txt8hello.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                Toast(MainActivity8.this,"Hello World clicked",)
//                txt8hello.setBackground(null);
//            }
//        });
//        txt8hello=findViewById(id.txt8hello);
//        txt8hello.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(MainActivity8.this,"Hello World clicked",Toast.LENGTH_SHORT).show();
//                txt8hello.setBackgroundColor(Color.parseColor("#a4c639"));
//            }
//        });

    }
    public void btn8selectclick(View view){
        Intent i = new Intent(MainActivity8.this,MainActivity9.class);
        startActivity(i);

    }
}