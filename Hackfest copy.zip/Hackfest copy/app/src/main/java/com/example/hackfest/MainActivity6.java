package com.example.hackfest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hackfest.R.id;

public class MainActivity6 extends AppCompatActivity {
    RadioButton rdbtnneuro;
   RadioGroup rdgrp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        rdbtnneuro = findViewById(R.id.rdbtnneuro);
        rdgrp=findViewById(id.rdgroup);
//        rdbtnneuro.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(MainActivity6.this,"Clicked radiobtn"+rdbtnneuro.getText(),Toast.LENGTH_LONG);
//            }
//        });
//    rdgrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//        @Override
//        public void onCheckedChanged(RadioGroup radioGroup, int i) {
//            rdbtnneuro.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                    Toast.makeText(MainActivity6.this,"Radiobutton clicked",Toast.LENGTH_LONG);
//                    TextView quest=findViewById(R.id.txt6ques);
//                    quest.setText("Clicked");
//                }
//            });
//            Toast.makeText(MainActivity6.this,"Radiogroup clicked",Toast.LENGTH_LONG).show();
//        }
//    });
    }
    public void btn6submitclick(View view){
        Intent i = new Intent(MainActivity6.this,MainActivity7.class);
        startActivity(i);
    }


//        rdbtnneuro.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                Toast.makeText(MainActivity6.this,"RadioButton Clicked on "+rdbtnneuro.getText(),Toast.LENGTH_LONG);
//                TextView quest=findViewById(R.id.txt6ques);
//                quest.setText("Clicked");
//            }
//        });
    }
