package com.example.hackfest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity11 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);
    }
    public void btn11homeclick(View view){
        Toast.makeText(MainActivity11.this,"Already in home",Toast.LENGTH_SHORT).show();
    }
    public void btn11bookingstatusclick(View view){
        Intent i=new Intent(MainActivity11.this,MainActivity4.class);
        startActivity(i);
    }
    public void btn11bookappoinclick(View view){
        Intent i=new Intent(MainActivity11.this,MainActivity6.class);
        startActivity(i);

    }
    public void btn11slotsbookedclick(View view){
        Intent i=new Intent(MainActivity11.this,MainActivity12.class);
        startActivity(i);

    }
    public void btn11profileclick(View view){
        Intent i=new Intent(MainActivity11.this,MainActivity2.class);
        startActivity(i);

    }
}