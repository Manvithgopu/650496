package com.example.hackfest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity10 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);
    }
    public void btn10profileclick(View view){
        Intent i=new Intent(MainActivity10.this,MainActivity5.class);
        startActivity(i);
    }
    public void btn10bookingstatusclick(View view){
        Intent i=new Intent(MainActivity10.this,MainActivity4.class);
        startActivity(i);
    }
    public void btn10bookappoinclick(View view){
        Intent i=new Intent(MainActivity10.this,MainActivity6.class);
        startActivity(i);
    }

}