package com.example.hackfest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity7 extends AppCompatActivity {
    RelativeLayout rltlyt1,rltlyt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        rltlyt1=findViewById(R.id.rltlyt71);
        rltlyt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity7.this,"Clicked First doctor",Toast.LENGTH_SHORT).show();

               Intent i=new Intent(MainActivity7.this,MainActivity8.class);
                startActivity(i);

            }
        });
    }
}